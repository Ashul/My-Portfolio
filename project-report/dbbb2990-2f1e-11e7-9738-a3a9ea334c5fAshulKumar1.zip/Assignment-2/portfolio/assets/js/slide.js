
function slides(){
  var slide = document.getElementById('slide');
  var slide1 = document.getElementById('slide1');
  var slide2 = document.getElementById('slide2');
  var slide3 = document.getElementById('slide3');
  var slide4 = document.getElementById('slide4');
  var slide5 = document.getElementById('slide5');
  var slide6 = document.getElementById('slide6');
  var slide7 = document.getElementById('slide7');
  var slide8 = document.getElementById('slide8');
  var slide9 = document.getElementById('slide9');
  var slide10 = document.getElementById('slide10');



  if(slide.style.pos !=0 && 
    slide1.style.pos !=0 && 
    slide2.style.pos !=0 && 
    slide3.style.pos !=0 && 
    slide4.style.pos !=0 &&
    slide5.style.pos !=0 &&
    slide6.style.pos !=0 && 
    slide7.style.pos !=0 && 
    slide8.style.pos !=0 &&
    slide9.style.pos !=0 &&
    slide10.style.pos !=0 


){
    slide.style.right = 20+'%';
    slide.style.bottom = 35+'%';

    slide1.style.right = 16+'%';
    slide1.style.bottom = 60+'%';

    slide2.style.right = 20+'%';
    slide2.style.bottom =23+'%';
    
    slide3.style.right = -18+'%';
    slide3.style.bottom = 28+'%';
    
    slide4.style.right = 1+'%';
    slide4.style.bottom = 7+'%';

    
    slide5.style.right = 10+'%';
    slide5.style.bottom = 46+'%';

    slide6.style.right = -11+'%';
    slide6.style.bottom = -10+'%';

    slide7.style.right = 11+'%';
    slide7.style.bottom = -17+'%';

    slide8.style.right = 28+'%';
    slide8.style.bottom = -12+'%';

    slide9.style.right = 45+'%';
    slide9.style.bottom = -8+'%';

    slide10.style.right = 31+'%';
    slide10.style.bottom = 13+'%';



  }
}